from src.data_preprocessing import load_data, preprocess
from src.feature_engineering import create_features
from src.train_models import train_xgb, save_models
from src.evaluate import evaluate_models

df = load_data("data/sales.xlsx")
df = preprocess(df)
df = create_features(df)

train = df[df['date'] < '2023-01-01']
test = df[df['date'] >= '2023-01-01']

X_train = train.drop(['sales','date','state'], axis=1)
y_train = train['sales']

X_test = test.drop(['sales','date','state'], axis=1)
y_test = test['sales']

xgb_model = train_xgb(X_train, y_train)

xgb_pred = xgb_model.predict(X_test)

best_model, scores = evaluate_models(y_test, {
    "xgboost": xgb_pred
})

print("Best Model:", best_model)
print("Scores:", scores)

save_models({"xgb": xgb_model})

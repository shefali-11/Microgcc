from fastapi import FastAPI
import joblib
import pandas as pd

app = FastAPI()

model = joblib.load("models/saved_models.pkl")["xgb"]

@app.get("/")
def home():
    return {"message": "Forecast API Running"}

@app.post("/predict")
def predict(data: dict):
    df = pd.DataFrame(data)
    preds = model.predict(df)
    return {"forecast": preds.tolist()}

import pandas as pd
from config import LAGS, ROLLING_WINDOWS

def create_features(df):
    df = df.copy()

    df['day_of_week'] = df['date'].dt.dayofweek
    df['month'] = df['date'].dt.month

    for lag in LAGS:
        df[f'lag_{lag}'] = df.groupby('state')['sales'].shift(lag)

    for window in ROLLING_WINDOWS:
        df[f'roll_mean_{window}'] = df.groupby('state')['sales'].shift(1).rolling(window).mean()
        df[f'roll_std_{window}'] = df.groupby('state')['sales'].shift(1).rolling(window).std()

    df = df.dropna()
    return df

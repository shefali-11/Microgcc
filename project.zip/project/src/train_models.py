import joblib
from xgboost import XGBRegressor
from statsmodels.tsa.statespace.sarimax import SARIMAX
from prophet import Prophet
import tensorflow as tf
from tensorflow.keras import layers

def train_xgb(X_train, y_train):
    model = XGBRegressor(n_estimators=100)
    model.fit(X_train, y_train)
    return model

def train_arima(series):
    model = SARIMAX(series, order=(1,1,1), seasonal_order=(1,1,1,7))
    return model.fit()

def train_prophet(df):
    p_df = df.rename(columns={'date': 'ds', 'sales': 'y'})
    model = Prophet()
    model.fit(p_df)
    return model

def train_lstm(X_train, y_train):
    model = tf.keras.Sequential([
        layers.LSTM(50, activation='relu', input_shape=(X_train.shape[1],1)),
        layers.Dense(1)
    ])

    model.compile(optimizer='adam', loss='mse')
    model.fit(X_train, y_train, epochs=5, verbose=0)

    return model

def save_models(models):
    joblib.dump(models, "models/saved_models.pkl")

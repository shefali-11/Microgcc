import pandas as pd

def load_data(path):
    df = pd.read_excel(path)
    df.columns = df.columns.str.lower()
    return df

def preprocess(df):
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values(['state', 'date'])
    df = df.set_index('date')

    df = df.groupby('state').apply(lambda x: x.asfreq('D')).reset_index()

    df['sales'] = df['sales'].fillna(method='ffill')

    return df

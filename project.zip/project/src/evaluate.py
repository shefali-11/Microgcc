from sklearn.metrics import mean_absolute_error

def evaluate_models(y_true, predictions_dict):
    scores = {}

    for name, pred in predictions_dict.items():
        scores[name] = mean_absolute_error(y_true, pred)

    best_model = min(scores, key=scores.get)

    return best_model, scores
